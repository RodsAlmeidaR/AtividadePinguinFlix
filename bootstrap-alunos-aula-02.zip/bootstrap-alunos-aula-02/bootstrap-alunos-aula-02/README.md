# Projeto PinguimFlix
Projeto desenvolvido com Bootstrap para aulas de desenvolvimento web

## Professor Júnior Gonçalves
[Hiperbytes](https://hiperbytes.com.br/)

### Tecnologias utilizadas 
* HTML5
* CSS3
* Boostrap
